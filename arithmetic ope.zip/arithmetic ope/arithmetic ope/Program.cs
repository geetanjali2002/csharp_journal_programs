﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace arithmetic_ope
{
    class Program
    {
        static void Main(string[] args)
        {
            int result;
            int x = 20, y = 15;

            result = (x + y);
            Console.WriteLine("Addition Operator: " + result);


            result = (x - y);
            Console.WriteLine("Subtraction Operator: " + result);


            result = (x * y);
            Console.WriteLine("Multiplication Operator: " + result);


            result = (x / y);
            Console.WriteLine("Division Operator: " + result);


            result = (x % y);
            Console.WriteLine("Modulo Operator: " + result);
            Console.Read();
        }
    }
}
