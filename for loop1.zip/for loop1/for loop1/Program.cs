﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace for_loop1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            for(i=1;i<=5;i++)
            {
                Console.WriteLine(i);
                Console.Read();
            }

        }
    }
}
