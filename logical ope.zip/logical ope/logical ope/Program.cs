﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace logical_ope
{
    class Program
    {
        static void Main(string[] args)
        {
            bool a = true, b = false, result;
 
            result = a && b;
            Console.WriteLine("AND Operator: " + result);

            
            result = a || b;
            Console.WriteLine("OR Operator: " + result);

           
            result = !a;
            Console.WriteLine("NOT Operator: " + result);
            Console.ReadKey();
        }
    }
}
