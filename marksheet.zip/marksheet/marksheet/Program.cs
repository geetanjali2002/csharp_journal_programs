﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace marksheet
{
    class Program
    {
        static void Main(string[] args)
        {
            int m1,m2,m3,total;
            float avg;
            Console.WriteLine("Enter marks");
            m1 = Convert.ToInt32(Console.ReadLine());
            m2 = Convert.ToInt32(Console.ReadLine());
            m3 = Convert.ToInt32(Console.ReadLine());
            total = m1 + m2 + m3;
            avg = total / 3;
            Console.WriteLine("PR:" + avg);
            if (avg >= 80)
            {
                Console.WriteLine("a");
            }
            else if (avg <= 80 && avg >= 60)
            {
                Console.WriteLine("b");
            }
            else if (avg <= 60 && avg >= 40)
            {
                Console.WriteLine("fail");
            }
            Console.Read();
        }
    }
}

            