﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace series_looping_pro
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, a = 1, b = 2, n;
            Console.WriteLine("enter loop");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Foor loop");
            Console.Write(a + "" + b + "");
            for (i = 3; i <= n; i++)
            {
                if (i % 2 == 1)
                {
                    a = a * 3;
                    Console.Write(a + "");
                }

                else
                {
                    b = b * 3;
                    Console.Write(b + "");
                }
            }

            //while loop
            Console.WriteLine("");
            a = 1; b = 2; i = 3;
            Console.WriteLine("While loop");
            Console.Write(a + "" + b + "");
            while(i<=n)
            {
                if(i%2==1)
                {
                    a=a*3;
                    Console.WriteLine(a + "");
                }

                else
                {
                    b=b*3;
                    Console.WriteLine(b + "");
                }
                i++;
            }

            //do whilw loop
            Console.WriteLine("Do while loop");
            Console.Write(a + "" + b + "");
            do
            {
                if(i%2==1)
                {
                    a=a*3;
                    Console.Write(a+"");
                }

                else
                {
                    b=b*3;
                    Console.Write(b+"");
                }
                while(i<=n);
                Console.Read();
            
            }
        }
    }
}