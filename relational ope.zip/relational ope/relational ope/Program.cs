﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace relational_ope
{
    class Program
    {
        static void Main(string[] args)
        {
            bool result;
        int x = 10, y = 15;
         
        
        result = (x == y);
        Console.WriteLine("Equal to Operator: " + result);
         
        
        result = (x > y);
        Console.WriteLine("Greater than Operator: " + result);
          
       
        result = (x < y);
        Console.WriteLine("Less than Operator: " + result);
         
        
        result = (x >= y);
        Console.WriteLine("Greater than or Equal to: "+ result);
         
        
        result = (x <= y);
        Console.WriteLine("Lesser than or Equal to: "+ result);
         
       
        result = (x != y);
        Console.WriteLine("Not Equal to Operator: " + result);
        Console.ReadKey();
        }
    }
}
